/**
 * Contains tests for Podam support for the Validator framework.
 * Created by tedonema on 21/06/2015.
 */
package uk.co.jemos.podam.test.unit.features.validatorFramework;