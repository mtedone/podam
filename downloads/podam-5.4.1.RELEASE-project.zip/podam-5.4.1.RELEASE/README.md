podam
=====

PODAM - POjo DAta Mocker

Podam (http://mtedone.github.io/podam/) is a Java testing tool which auto-fills POJOs with made-up data.

Podam can fill any tree of objects with data. It supports generics, collections, arrays and Java native types. 

To get an idea of Podam's full potential, please visit the Podam website.
