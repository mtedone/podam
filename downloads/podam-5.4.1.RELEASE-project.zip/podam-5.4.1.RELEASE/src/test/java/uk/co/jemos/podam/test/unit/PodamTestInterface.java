package uk.co.jemos.podam.test.unit;

/**
 * @author divanov
 */
public interface PodamTestInterface {
}
